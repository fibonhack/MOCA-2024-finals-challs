## tracer

This code is forked from [takahirox/riscv-rust](https://github.com/takahirox/riscv-rust) with modifications to support a new memory layout and additional tracing. All credit goes to the original author.
