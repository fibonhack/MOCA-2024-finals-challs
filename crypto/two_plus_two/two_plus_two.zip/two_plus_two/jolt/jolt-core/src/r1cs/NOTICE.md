[`spartan.rs`](./spartan.rs), `snark.rs`, and `r1cs_shape.rs` were forked from the [Spartan2](https://github.com/microsoft/Spartan2) codebase, under the [MIT License](https://github.com/microsoft/Spartan2/blob/main/LICENSE).

This version of Spartan contains optimizations leveraging the uniformity of the Jolt R1CS circuit. 