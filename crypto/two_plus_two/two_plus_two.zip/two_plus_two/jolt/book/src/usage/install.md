# Installing
Start by installing the `jolt` command line tool.
```
cargo +nightly install --git https://github.com/a16z/jolt --force --bins jolt
```

