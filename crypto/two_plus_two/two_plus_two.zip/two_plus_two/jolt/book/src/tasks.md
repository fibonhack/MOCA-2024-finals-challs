> All of the open tasks are tracked via [Github Issues](https://github.com/a16z/jolt/issues).

![Jolt Skill Tree](imgs/jolt-skill-tree.png)
