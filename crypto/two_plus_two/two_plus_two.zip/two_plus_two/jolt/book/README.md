# Jolt Book
The Jolt Book runs on [mdBook](https://rust-lang.github.io/mdBook/). Serve locally with `cd book && mdbook serve`.

## Deps
- `cargo install mdbook`
- `cargo install mdbook-katex`: Latex is rendered at compile time with [mdbook-katex](https://github.com/lzanini/mdbook-katex).
